{{/*
Expand the name of the chart.
*/}}
{{- define "eva-app.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "eva-app.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "eva-app.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "eva-app.labels" -}}
helm.sh/chart: {{ include "eva-app.chart" . }}
{{ include "eva-app.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "eva-app.selectorLabels" -}}
app.kubernetes.io/name: {{ include "eva-app.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
component: eva-app
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "eva-app.serviceAccount.name" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "eva-app.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- printf "%s" (.Values.serviceAccount.existingServiceAccount) }}
{{- end }}
{{- end }}


{{/*
Define secret name
*/}}
{{- define "eva-app.secret.name" -}}
{{- if and .Values.secret .Values.secret.nameOverride }}
{{- .Values.secret.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Define pv name
*/}}
{{- define "eva-app.pv.name" -}}
{{- if and .Values.pv .Values.pv.nameOverride }}
{{- .Values.pv.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "pv-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}


{{/*
Define pvc name
*/}}
{{- define "eva-app.pvc.name" -}}
{{- if and .Values.pvc .Values.pvc.nameOverride }}
{{- .Values.pvc.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "pvc-%s" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end}}


{{/*
Define imagePullSecret name
*/}}
{{- define "eva-app.imagePullSecret.name" -}}
{{- if .Values.imagePullSecrets.nameOverride }}
{{- .Values.imagePullSecrets.nameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret-regcred" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Define tls secret name
*/}}
{{- define "eva-app.tlsSecret.name" -}}
{{- if .Values.ingress.tls.secretNameOverride }}
{{- .Values.ingress.tls.secretNameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-secret-tls" (.Release.Name) | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Return true when app.backendHost is an IPv4 or IPv6 address.
Kubernetes Ingress host fields accept DNS names only; IP addresses require a
hostless rule instead.
*/}}
{{- define "eva-app.backendHost.isIp" -}}
{{- $host := toString .Values.app.backendHost -}}
{{- if or (regexMatch "^[0-9]{1,3}(\\.[0-9]{1,3}){3}$" $host) (contains ":" $host) -}}
true
{{- end -}}
{{- end }}
